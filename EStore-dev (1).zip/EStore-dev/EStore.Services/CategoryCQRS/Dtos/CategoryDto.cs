﻿namespace EStore.Services.CategoryCQRS.Dtos
{
    public class CategoryDto 
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}