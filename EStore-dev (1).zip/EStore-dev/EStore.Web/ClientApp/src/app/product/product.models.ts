﻿export class Product{
  id: number;
  name: string;
  categoryName: string;
  brandName: string;
  price: number;
  rating: number;
}
